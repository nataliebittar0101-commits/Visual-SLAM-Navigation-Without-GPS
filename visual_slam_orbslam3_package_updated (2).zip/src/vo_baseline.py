#!/usr/bin/env python3

import cv2
import numpy as np
import argparse

def draw_traj(traj, pose, scale=1.0):
    x, z = pose[0,3], pose[2,3]
    u, v = int(300 + scale*x), int(300 + scale*z)
    cv2.circle(traj, (u, v), 2, (255,255,255), 2)
    cv2.imshow("Trajectory", traj)
    cv2.waitKey(1)

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--video", type=str, required=True, help="Path to video file")
    args = parser.parse_args()

    cap = cv2.VideoCapture(args.video)
    if not cap.isOpened():
        raise SystemExit("Could not open video")

    lk_params = dict(winSize=(21, 21), maxLevel=3,
                     criteria=(cv2.TERM_CRITERIA_EPS | cv2.TERM_CRITERIA_COUNT, 30, 0.01))
    detector = cv2.GFTTDetector_create(maxCorners=2000, qualityLevel=0.01, minDistance=7, blockSize=7)

    ret, prev = cap.read()
    if not ret:
        raise SystemExit("Empty video")
    prev_gray = cv2.cvtColor(prev, cv2.COLOR_BGR2GRAY)
    pts_prev = detector.detect(prev_gray)
    pts_prev = np.array([kp.pt for kp in pts_prev], dtype=np.float32)

    K = np.array([[700,0,prev_gray.shape[1]/2],
                  [0,700,prev_gray.shape[0]/2],
                  [0,0,1]], dtype=np.float64)

    traj = np.zeros((600, 600, 3), dtype=np.uint8)
    R = np.eye(3)
    t = np.zeros((3,1))

    while True:
        ret, frame = cap.read()
        if not ret:
            break
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)

        pts_next, st, err = cv2.calcOpticalFlowPyrLK(prev_gray, gray, pts_prev, None, **lk_params)
        good_prev = pts_prev[st.flatten()==1]
        good_next = pts_next[st.flatten()==1]

        if len(good_prev) >= 8:
            E, mask = cv2.findEssentialMat(good_next, good_prev, K, cv2.RANSAC, 0.999, 1.0)
            if E is not None:
                _, R_new, t_new, mask_pose = cv2.recoverPose(E, good_next, good_prev, K)
                scale = 1.0
                t = t + R.dot(t_new) * scale
                R = R_new.dot(R)
                pose = np.eye(4)
                pose[:3,:3] = R
                pose[:3,3:] = t
                draw_traj(traj, pose, scale=50)

        prev_gray = gray
        if len(good_next) < 500:
            pts_next = detector.detect(gray)
            pts_next = np.array([kp.pt for kp in pts_next], dtype=np.float32)
        pts_prev = pts_next

        cv2.imshow("Frame", frame)
        if cv2.waitKey(1) & 0xFF == 27:
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
