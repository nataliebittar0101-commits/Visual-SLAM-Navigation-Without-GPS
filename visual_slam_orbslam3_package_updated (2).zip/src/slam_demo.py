#!/usr/bin/env python3

import os
import sys
import argparse
import subprocess
from pathlib import Path

def main():
    parser = argparse.ArgumentParser(description="Python launcher for ORB-SLAM3 monocular demo")
    parser.add_argument("--orb_path", type=str, default=str(Path.home()/"ORB_SLAM3"),
                        help="Path to ORB_SLAM3 root folder")
    parser.add_argument("--vocab", type=str, default=None, help="Path to ORB vocabulary file (ORBvoc.txt)")
    parser.add_argument("--settings", type=str, default=None, help="Path to camera settings YAML")
    parser.add_argument("--video", type=str, default="/dev/video0",
                        help="Input video path or camera device (default: /dev/video0)")
    args = parser.parse_args()

    orb_path = Path(args.orb_path)
    vocab = Path(args.vocab) if args.vocab else orb_path/"Vocabulary/ORBvoc.txt"
    settings = Path(args.settings) if args.settings else orb_path/"Examples/Monocular/TUM1.yaml"
    mono_bin = orb_path/"Examples/Monocular/mono_tum"

    if not mono_bin.exists():
        print(f"[!] ORB-SLAM3 binary not found at: {mono_bin}")
        print("    Build ORB-SLAM3 first (see scripts/install_ubuntu.sh).")
        sys.exit(1)
    if not vocab.exists():
        print(f"[!] Vocabulary not found at: {vocab}")
        sys.exit(1)
    if not settings.exists():
        print(f"[!] Settings YAML not found at: {settings}")
        sys.exit(1)

    cmd = [str(mono_bin), str(vocab), str(settings), str(args.video)]
    print("[*] Launching:", " ".join(cmd))
    env = os.environ.copy()
    subprocess.run(cmd, env=env, check=False)

if __name__ == "__main__":
    main()
