# Visual-SLAM Navigation Without GPS — ORB-SLAM3 (Monocular RGB)

**Course Project in Real Time System, University of Haifa Report**  
**Team:** Natalie Bittar – ID 212586044  
Hanaa Mahajna - ID 314783317
**Date: 2025-08-29** 2025-08-29

## Abstract
We present a GPS-denied navigation and mapping system using a single RGB camera powered by ORB-SLAM3.
We demonstrate real-time monocular mapping and camera tracking in indoor environments and provide a
fallback monocular VO pipeline for environments where ORB-SLAM3 cannot be compiled.

## Objectives
- Build and run monocular ORB-SLAM3 on Linux.
- Map indoor spaces and record the camera trajectory.
- Evaluate stability under lighting and motion variations.
- Provide a clean codebase, documentation, and demo materials.

## Methods
- ORB-SLAM3 (C++) launched via a small Python wrapper.
- Camera calibration via a YAML file.
- Dataset and live video capture; baseline VO implemented in OpenCV for fallback.

## Experiments & Results
- Scenario 1: Small room walkthrough (good lighting). Stable tracking; smooth trajectory.
- Scenario 2: Corridor with turns (mixed lighting). Tracking recovers after rapid rotations.
- Baseline VO shows drift as expected; serves as diagnostic tool.
- Metrics: FPS ~ 20-30 (depending on machine); qualitative map density increases with richer textures.

## Discussion
Monocular SLAM requires careful motion (avoid extreme blur) and sufficient parallax. Calibration quality
is critical. Adding IMU or stereo would improve scale observability and robustness.

## Conclusion
Our minimal system enables real-time monocular SLAM and provides a practical template for further research
and coursework projects, including navigation, planning, and semantic mapping extensions.

## Acknowledgments
We thank UZ-SLAMLab (ORB-SLAM3 authors), the OpenCV community, and ChatGPT.

## References
See `docs/CITATIONS.txt` in this package.
