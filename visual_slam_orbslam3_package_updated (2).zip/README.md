# Visual-SLAM Navigation Without GPS (ORB-SLAM3, Monocular RGB)

This repository contains a complete course project package: code skeletons, Linux installation script,
documentation, slides, and demo media. The system targets **Linux (Ubuntu 20.04/22.04)** and a single RGB camera.

## Contents
- `src/slam_demo.py` — Python launcher that spawns ORB-SLAM3 monocular example (webcam or video file).
- `src/vo_baseline.py` — Minimal monocular Visual Odometry (pure OpenCV) as a fallback if you cannot compile ORB-SLAM3.
- `config/camera.yaml` — Camera calibration template.
- `scripts/install_ubuntu.sh` — One-shot installer for Ubuntu dependencies and ORB-SLAM3.
- `docs/report.pdf` — Ready-to-submit report.
- `docs/report.md` — Report source in Markdown (for editing).
- `docs/CITATIONS.txt` — Sources and acknowledgments.
- `media/demo_placeholder.mp4` — Synthetic placeholder video (replace with a real room/ corridor recording).
- `slides/project_slides.pptx` — Presentation slides for class/ demo day.

## Quick Start (Linux)
```bash
# 1) Install deps + ORB-SLAM3 (this takes a while)
bash scripts/install_ubuntu.sh

# 2) (Optional) Test fallback VO if ORB-SLAM3 isn't built yet
python3 src/vo_baseline.py --video media/demo_placeholder.mp4

# 3) Run ORB-SLAM3 with webcam (adjust paths inside src/slam_demo.py)
python3 src/slam_demo.py
```

## Notes
- ORB-SLAM3 is C++ and requires compilation. The Python launcher simply **executes** its example binary (`mono_tum`).
- For best results, provide a **camera calibration** in `config/camera.yaml`.
- Replace `media/demo_placeholder.mp4` with a real video walking around a room/ corridor; keep moderate speed and avoid motion blur.

## Team
- Natalie Bittar – ID 212586044
- Hanna Mahajna - ID 314783317


## License
See `LICENSE.txt` (Apache-2.0 for your original files; ORB-SLAM3 is licensed separately in its own repository).
