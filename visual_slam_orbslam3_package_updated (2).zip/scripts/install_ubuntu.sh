#!/usr/bin/env bash
set -e

echo "[*] Updating system..."
sudo apt update
sudo apt -y upgrade

echo "[*] Installing build deps..."
sudo apt -y install build-essential cmake git pkg-config
sudo apt -y install libopencv-dev libeigen3-dev libboost-all-dev
sudo apt -y install libpangolin-dev

echo "[*] Installing Python deps..."
sudo apt -y install python3-dev python3-pip python3-numpy

echo "[*] Cloning ORB-SLAM3..."
if [ ! -d "$HOME/ORB_SLAM3" ]; then
  git clone https://github.com/UZ-SLAMLab/ORB_SLAM3.git $HOME/ORB_SLAM3
fi

echo "[*] Building ORB-SLAM3 (this can take a while)..."
cd $HOME/ORB_SLAM3
chmod +x build.sh
./build.sh

echo "[*] Done. Example binary should exist at: $HOME/ORB_SLAM3/Examples/Monocular/mono_tum"
