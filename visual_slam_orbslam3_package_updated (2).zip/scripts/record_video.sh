#!/usr/bin/env bash
# Record a real-world walkthrough from /dev/video0 to MP4 (requires ffmpeg).
# Usage: bash scripts/record_video.sh output.mp4
set -e
OUT=${1:-media/room_walkthrough.mp4}
ffmpeg -f v4l2 -framerate 30 -video_size 640x480 -i /dev/video0 -vcodec libx264 -pix_fmt yuv420p -y "$OUT"
echo "Saved: $OUT"
